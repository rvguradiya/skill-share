import java.util.*;
class ADTO
{
private int id;
private String name;
private String city;
private int code;
public int getId()
{
return this.id;
}
public String getName()
{
return this.name;
}
public int getCode()
{
return this.code;
}
public String getCity()
{
return this.city;
}
}