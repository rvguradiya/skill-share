package dto;
public class StateDTO
{
private int code;
private String name;
private int countryCode;
public void setCode(int code)
{
this.code=code;
}
public int getCode()
{
return this.code;
}
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return this.name;
}
public void setCountryCode(int countryCode)
{
this.countryCode=countryCode;
}
public int getCountryCode()
{
return this.countryCode;
}
}