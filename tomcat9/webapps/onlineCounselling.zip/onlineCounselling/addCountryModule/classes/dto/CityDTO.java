package dto;
public class CityDTO
{
private int code;
private String name;
private int stateCode;
public void setCode(int code)
{
this.code=code;
}
public int getCode()
{
return this.code;
}
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return this.name;
}
public void setStateCode(int stateCode)
{
this.stateCode=stateCode;
}
public int getStateCode()
{
return this.stateCode;
}
}