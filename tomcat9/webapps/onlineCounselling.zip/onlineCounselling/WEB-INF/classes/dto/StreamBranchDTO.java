package dto;
public class StreamBranchDTO
{
//private int streamCode;
//private int  branchCode;

}