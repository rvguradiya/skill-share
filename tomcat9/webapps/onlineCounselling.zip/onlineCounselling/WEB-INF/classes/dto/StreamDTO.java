package dto;
public class StreamDTO
{
private int code;
private String name;
private String fullName;
public void setCode(int code)
{
this.code=code;
}
public int getCode()
{
return this.code;
}
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return this.name;
}
public void setFullName(String fullName)
{
this.fullName=fullName;
}
public String getFullName()
{
return this.fullName;
}
}