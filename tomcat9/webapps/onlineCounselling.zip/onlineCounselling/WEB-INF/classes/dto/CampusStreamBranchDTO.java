package dto;
public class CampusStreamBranchDTO
{
//private int campusCode
//private int streamCode;
//private int  branchCode;
//private int numberOfSeats;
}
