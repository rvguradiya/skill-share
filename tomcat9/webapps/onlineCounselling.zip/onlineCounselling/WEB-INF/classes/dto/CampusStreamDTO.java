package dto;
public class CampusStreamDTO
{
//private int streamCode;
//private int  campusCode;
}