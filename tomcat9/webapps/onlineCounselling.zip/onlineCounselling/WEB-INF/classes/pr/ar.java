import java.util.*;
class ar
{
public static void main(String gg[])
{
ArrayList<String> a=new ArrayList<>();
a.add("kdjf");
a.add("kdjdddd");
System.out.println(a.get(0));
System.out.println(a.get(1));
System.out.println(a.get(0));
System.out.println(a.get(2));


}
}