package skill.share.project.skillshare.dl;
import java.io.*;
//import java.util.Date;
//import java.sql.Timestamp;
public class ThreadDetailsRequestDTO
{
private int threadId;
public void setThreadId(int threadId)
{
this.threadId=threadId;
}
public int getThreadId()
{
return this.threadId;
}
}
