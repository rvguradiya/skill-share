package skill.share.project.skillshare.dl;
import java.io.*;
//import java.util.Date;
//import java.sql.Timestamp;
public class SearchRequestDTO
{
private String searchString;
public void setSearchString(String searchString)
{
this.searchString=searchString;
}
public String getSearchString()
{
return this.searchString;
}
}
