package skill.share.project.skillshare;
import java.io.*;
public class ApplicationResponse implements Serializable
{
//public boolean isSuccess=false;
//public boolean isException=false;
//public String exception="";
//public String error="";
public Object result;
}