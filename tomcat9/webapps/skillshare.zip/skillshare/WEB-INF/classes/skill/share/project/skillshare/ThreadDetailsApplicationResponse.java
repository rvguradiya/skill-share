package skill.share.project.skillshare;
import java.io.*;
public class ThreadDetailsApplicationResponse implements Serializable
{
public Object thread;
public Object comments;
}