package skill.share.project.skillshare.dl;
public class DAOException extends Exception
{
public DAOException(String message)
{
super(message);
}
}